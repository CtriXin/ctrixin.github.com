'use strict';
/**
 * session adapter
 */
export default class extends think.adapter.session {
  /**
   * init
   * @return {[]}         []
   */
  init(...args){
    super.init(...args);
  }
}