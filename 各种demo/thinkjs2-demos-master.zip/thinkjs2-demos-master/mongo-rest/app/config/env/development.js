'use strict';

exports.__esModule = true;
exports['default'] = {};
module.exports = exports['default'];