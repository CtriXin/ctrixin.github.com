'use strict';
/**
 * config
 */
export default {
  host: 8360
  //key: value
};