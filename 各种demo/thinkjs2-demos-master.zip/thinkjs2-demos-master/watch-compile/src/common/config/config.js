'use strict';
/**
 * config
 */
export default {
  log_auto_reload: true
  //key: value
};