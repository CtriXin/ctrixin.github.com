'use strict';
/**
 * config
 * @type {Object}
 */
module.exports = {
  //key: value
};