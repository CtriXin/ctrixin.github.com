/**
 * this file will be loaded before server started
 * you can register app hook
 */
