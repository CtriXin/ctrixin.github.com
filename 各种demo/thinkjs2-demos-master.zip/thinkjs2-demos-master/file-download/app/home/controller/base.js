'use strict';

module.exports = think.controller({
  /**
   * some base method in here
   */
});