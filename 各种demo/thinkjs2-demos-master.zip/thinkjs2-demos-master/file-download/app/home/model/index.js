'use strict';
/**
 * model
 * @type {Class}
 */
module.exports = think.model({

});