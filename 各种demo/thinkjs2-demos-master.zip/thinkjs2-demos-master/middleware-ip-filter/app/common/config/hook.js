module.exports = {
  request_begin: ['prepend', 'ip_filter']
}