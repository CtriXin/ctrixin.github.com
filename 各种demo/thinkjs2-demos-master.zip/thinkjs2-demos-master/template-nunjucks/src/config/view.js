'use strict';
/**
 * template config
 */
export default {
  type: 'nunjucks',
  content_type: 'text/html',
  file_ext: '.html',
  file_depr: '_',
  root_path: think.ROOT_PATH + '/view',
  prerender: (nunjucks, env) => {
    console.log('prerender outside');
  },
  adapter: {
    nunjucks: {
      prerender: (nunjucks, env) => {
        console.log('prerender inside');
        env.addFilter('thinkjs', function(){
          return 1111;
        })
      } 
    }
  }
};