'use strict';

export default {
    view_filter : ['append', 'debug_toolbar'],
}