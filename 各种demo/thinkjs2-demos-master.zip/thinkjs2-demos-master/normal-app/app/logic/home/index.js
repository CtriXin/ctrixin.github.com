'use strict';
/**
 * logic
 * @param  {} []
 * @return {}     []
 */
module.exports = think.logic({
  /**
   * index action logic
   * @return {} []
   */
  indexAction: function(){
    // this.rules = {
    //   name: 'required'
    // }
  }
});