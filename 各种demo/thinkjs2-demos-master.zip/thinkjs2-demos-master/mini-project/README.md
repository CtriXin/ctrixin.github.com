## README

application created by [ThinkJS](http://www.thinkjs.org)

## install dependencies

```
npm install
```

## watch-compile

```
npm run watch-compile
```

## start server

```
npm start
```

## deploy with pm2

```
pm2 startOrGracefulReload pm2.json
```