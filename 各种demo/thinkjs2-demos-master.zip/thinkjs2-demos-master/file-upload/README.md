## README

application created by [ThinkJS](http://www.thinkjs.org)

## install dependencies

```
npm install
```

## start server

```
npm start
```

## deploy with pm2

```
pm2 startOrGracefulReload pm2.json
```