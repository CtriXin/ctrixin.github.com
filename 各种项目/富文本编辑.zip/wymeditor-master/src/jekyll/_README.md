This Jekyll setup is documented in the [WYMeditor
documentation](http://wymeditor.readthedocs.org/en/master/wymeditor_development/wymeditor_website.html).
