WYMeditor.EXTERNAL_MODULES.ObjectHistory = require("object-history");
