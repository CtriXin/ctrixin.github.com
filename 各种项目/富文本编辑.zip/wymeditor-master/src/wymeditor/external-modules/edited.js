WYMeditor.EXTERNAL_MODULES.Edited = require("edited");
