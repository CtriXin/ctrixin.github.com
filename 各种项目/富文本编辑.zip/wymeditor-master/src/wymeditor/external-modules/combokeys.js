WYMeditor.EXTERNAL_MODULES.Combokeys = require("combokeys");
