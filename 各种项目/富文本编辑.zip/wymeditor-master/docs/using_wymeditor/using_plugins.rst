#######################
Using WYMeditor Plugins
#######################

.. todo::

    Broad explanation of plugins,
    how to find them
    and how to use them.
