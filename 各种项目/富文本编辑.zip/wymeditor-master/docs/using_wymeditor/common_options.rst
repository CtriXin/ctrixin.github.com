########################
Common WYMeditor Options
########################

.. todo::

    Split the options from customizing_wymeditor/index
    in to common and otherwise.

