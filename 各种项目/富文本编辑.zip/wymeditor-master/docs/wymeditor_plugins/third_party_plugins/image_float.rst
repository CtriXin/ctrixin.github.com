Image Float (by Patabugen)
==========================

https://bitbucket.org/Patabugen/wymeditor-plugins/src

Float images with classes.

