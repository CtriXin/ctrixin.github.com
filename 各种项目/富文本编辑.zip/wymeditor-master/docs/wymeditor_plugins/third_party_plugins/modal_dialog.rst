Modal Dialog (by samuelcole)
============================

https://github.com/samuelcole/modal_dialog

Replaces the default dialog behavior (new window) with a modal dialog. Known
bug in IE, more information `here
<https://github.com/wymeditor/wymeditor/issues/67>`_.

