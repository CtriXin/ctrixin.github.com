Catch Paste
===========

Force automatic "Paste From Word" usage so that all pasted content is properly
cleaned.

http://forum.wymeditor.org/forum/viewtopic.php?f=2&t=676

