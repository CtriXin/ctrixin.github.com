Alignment (by Patabugen)
========================

https://bitbucket.org/Patabugen/wymeditor-plugins/src

Set Text Alignment with classes.

