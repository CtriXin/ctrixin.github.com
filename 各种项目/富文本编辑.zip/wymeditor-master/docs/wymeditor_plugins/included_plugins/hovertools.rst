Hovertools
==========

This plugin improves visual feedback by:

* displaying a tool's title in the status bar while the mouse hovers over it.
* changing background color of elements which match a condition, e.g. on which
  a class can be applied.

