Included Plugins with Download
==============================

.. toctree::
    :maxdepth: 2

    embed
    fullscreen
    hovertools
    list
    rdfa
    resizable
    table
    tidy
    structured_headings
